// src/api/roomApi.js
// API functions untuk rooms (public endpoints)
import axiosInstance from './axios'

/**
 * Dapatkan detail room by ID
 * @param {number} id - Room ID
 * @returns {Promise} Data room
 */
export const getRoom = async (id) => {
  const response = await axiosInstance.get(`/rooms/${id}`)
  return response.data
}

/**
 * Cek ketersediaan room
 * @param {Object} params - Checkin, checkout, guests
 * @returns {Promise} List rooms yang available
 */
export const getAvailableRooms = async (params) => {
  const response = await axiosInstance.post('/rooms/available', params)
  return response.data
}

// Contoh request dan response structure:
/*
Get Room Response:
{
  "id": 1,
  "name": "Deluxe Room",
  "description": "Luxurious room with king bed",
  "price": 250000,
  "capacity": 2,
  "size": 45,
  "amenities": ["WiFi", "AC", "TV"],
  "images": [
    {
      "id": 1,
      "url": "https://via.placeholder.com/800x600",
      "caption": "Room view"
    }
  ]
}

Available Rooms Request:
{
  "checkin": "2024-01-15",
  "checkout": "2024-01-20",
  "guests": 2
}

Available Rooms Response:
{
  "rooms": [
    {
      "id": 1,
      "name": "Deluxe Room",
      "price": 250000,
      "available": true
    }
  ]
}
*/