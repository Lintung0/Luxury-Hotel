// src/router/AppRouter.jsx
// Main router configuration untuk aplikasi
import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import ProtectedRoute from './ProtectedRoute'
import AdminRoute from './AdminRoute'
import MemberRoute from './MemberRoute'


// Layouts
import MainLayout from '../layouts/MainLayout'
import AdminLayout from '../layouts/AdminLayout'

// Pages
import Home from '../pages/Home'
import Rooms from '../pages/Rooms'
import RoomDetail from '../pages/RoomDetail'
import Login from '../components/auth/Login'
import Register from '../components/auth/Register'
import MemberBookings from '../pages/Member/MemberBookings'
import AdminDashboard from '../pages/Admin/AdminDashboard'

// Skeleton
import PageSkeleton from '../components/ui/PageSkeleton'

const AppRouter = () => {
  const { loading, user } = useAuth()

  if (loading) {
    return <PageSkeleton />
  }

  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/login" element={
        <MainLayout>
          <Login />
        </MainLayout>
      } />
      <Route path="/register" element={
        <MainLayout>
          <Register />
        </MainLayout>
      } />
      
      {/* Protected Routes with Main Layout */}
      <Route path="/" element={
        <MainLayout>
          <Home />
        </MainLayout>
      } />
      <Route path="/rooms" element={
        <MainLayout>
          <Rooms />
        </MainLayout>
      } />
      <Route path="/rooms/:id" element={
        <MainLayout>
          <RoomDetail />
        </MainLayout>
      } />

      {/* Member Routes */}
      <Route path="/member/bookings" element={
        <ProtectedRoute>
          <MainLayout>
            <MemberBookings />
          </MainLayout>
        </ProtectedRoute>
      } />

      {/* Admin Routes */}
      <Route path="/admin/*" element={
        <AdminRoute>
          <AdminLayout>
            <Routes>
              <Route path="/" element={<AdminDashboard />} />
              <Route path="/rooms" element={<div>Admin Rooms</div>} />
              <Route path="/bookings" element={<div>Admin Bookings</div>} />
              <Route path="/users" element={<div>Admin Users</div>} />
              <Route path="/reviews" element={<div>Admin Reviews</div>} />
            </Routes>
          </AdminLayout>
        </AdminRoute>
      } />

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}

export default AppRouter