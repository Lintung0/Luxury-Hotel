// src/context/AuthContext.jsx
import React, { createContext, useContext, useState, useEffect } from 'react'
import { getMe, login as loginApi, register as registerApi } from '../api/authApi'
import { saveToken, getToken, removeToken, getRole } from '../utils/auth'

const AuthContext = createContext()

// Hapus export yang tidak diperlukan untuk context
// export const useAuth = () => {
//   const context = useContext(AuthContext)
//   if (!context) {
//     throw new Error('useAuth must be used within AuthProvider')
//   }
//   return context
// }

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const initAuth = async () => {
      const token = getToken()
      if (token) {
        try {
          const userData = await getMe()
          setUser(userData)
        } catch (error) {
          console.error('Auto login failed:', error)
          removeToken()
        }
      }
      setLoading(false)
    }

    initAuth()
  }, [])

  const login = async (credentials) => {
    const response = await loginApi(credentials)
    saveToken(response.token)
    setUser(response.user)
    return response
  }

  const register = async (userData) => {
    const response = await registerApi(userData)
    return response
  }

  const logout = () => {
    removeToken()
    setUser(null)
  }

  const value = {
    user,
    login,
    register,
    logout,
    loading,
    isAuthenticated: !!user,
    isAdmin: getRole() === 'ADMIN',
    isMember: getRole() === 'MEMBER'
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}

// Export custom hook terpisah
export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider')
  }
  return context
}