// src/context/ThemeContext.jsx
import React, { createContext, useContext, useState, useEffect } from 'react'
import { getStoredValue, setStoredValue, THEME_STORAGE_KEY, DEFAULT_THEME } from './constants'

const ThemeContext = createContext()

export const ThemeProvider = ({ children }) => {
  const [isDark, setIsDark] = useState(() => {
    return getStoredValue(THEME_STORAGE_KEY, DEFAULT_THEME === 'dark')
  })

  useEffect(() => {
    setStoredValue(THEME_STORAGE_KEY, isDark)
    if (isDark) {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
  }, [isDark])

  const toggleTheme = () => {
    setIsDark(prev => !prev)
  }

  const value = {
    isDark,
    toggleTheme,
    theme: isDark ? 'dark' : 'light'
  }

  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  )
}

// Export custom hook terpisah
export const useTheme = () => {
  const context = useContext(ThemeContext)
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider')
  }
  return context
}