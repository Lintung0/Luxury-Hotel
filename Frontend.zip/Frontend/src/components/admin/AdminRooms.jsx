// src/components/admin/AdminRooms.jsx
// Component untuk admin room management dengan CRUD operations
import React, { useState, useEffect } from 'react'
import { 
  getAdminRooms, 
  createRoom, 
  updateRoom, 
  deleteRoom,
  uploadRoomImage,
  deleteRoomImage 
} from '../../api/adminApi/adminRoomApi'
import AdminTableSkeleton from '../ui/AdminTableSkeleton'
import { formatCurrency } from '../../utils/formatter'

const AdminRooms = () => {
  const [rooms, setRooms] = useState([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [showImageModal, setShowImageModal] = useState(false)
  const [editingRoom, setEditingRoom] = useState(null)
  const [selectedRoom, setSelectedRoom] = useState(null)
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    capacity: '',
    size: '',
    amenities: '',
    type: 'STANDARD'
  })
  const [imageForm, setImageForm] = useState({
    caption: '',
    image: null
  })

  useEffect(() => {
    loadRooms()
  }, [])

  const loadRooms = async () => {
    try {
      const data = await getAdminRooms()
      setRooms(data.rooms || data)
    } catch (error) {
      console.error('Failed to load rooms:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      const roomData = {
        ...formData,
        price: parseInt(formData.price),
        capacity: parseInt(formData.capacity),
        size: parseInt(formData.size),
        amenities: formData.amenities.split(',').map(a => a.trim()).filter(a => a)
      }

      if (editingRoom) {
        await updateRoom(editingRoom.id, roomData)
      } else {
        await createRoom(roomData)
      }

      setShowModal(false)
      setEditingRoom(null)
      resetForm()
      loadRooms()
    } catch (error) {
      console.error('Failed to save room:', error)
      alert('Failed to save room: ' + (error.response?.data?.message || error.message))
    }
  }

  const handleEdit = (room) => {
    setEditingRoom(room)
    setFormData({
      name: room.name,
      description: room.description,
      price: room.price.toString(),
      capacity: room.capacity.toString(),
      size: room.size.toString(),
      amenities: room.amenities?.join(', ') || '',
      type: room.type || 'STANDARD'
    })
    setShowModal(true)
  }

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this room?')) {
      try {
        await deleteRoom(id)
        loadRooms()
      } catch (error) {
        console.error('Failed to delete room:', error)
        alert('Failed to delete room: ' + (error.response?.data?.message || error.message))
      }
    }
  }

  const handleImageUpload = async (e) => {
    e.preventDefault()
    if (!selectedRoom || !imageForm.image) return

    try {
      const formData = new FormData()
      formData.append('image', imageForm.image)
      formData.append('caption', imageForm.caption)

      await uploadRoomImage(selectedRoom.id, formData)
      setShowImageModal(false)
      setImageForm({ caption: '', image: null })
      loadRooms()
    } catch (error) {
      console.error('Failed to upload image:', error)
      alert('Failed to upload image: ' + (error.response?.data?.message || error.message))
    }
  }

  const handleImageDelete = async (imageId) => {
    if (window.confirm('Are you sure you want to delete this image?')) {
      try {
        await deleteRoomImage(imageId)
        loadRooms()
      } catch (error) {
        console.error('Failed to delete image:', error)
        alert('Failed to delete image: ' + (error.response?.data?.message || error.message))
      }
    }
  }

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      price: '',
      capacity: '',
      size: '',
      amenities: '',
      type: 'STANDARD'
    })
  }

  const openImageModal = (room) => {
    setSelectedRoom(room)
    setShowImageModal(true)
  }

  if (loading) {
    return <AdminTableSkeleton />
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          Room Management
        </h1>
        <button
          onClick={() => setShowModal(true)}
          className="bg-gold-600 hover:bg-gold-700 text-white px-4 py-2 rounded-md font-medium transition-colors"
        >
          Add New Room
        </button>
      </div>

      <div className="bg-white dark:bg-gray-800 shadow-lg rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Room
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Type
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Price
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Capacity
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Size
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Images
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {rooms.map((room) => (
                <tr key={room.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">
                      {room.name}
                    </div>
                    <div className="text-sm text-gray-500 dark:text-gray-400 truncate max-w-xs">
                      {room.description}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                    {room.type || 'STANDARD'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                    {formatCurrency(room.price)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                    {room.capacity} guests
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                    {room.size}m²
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                    {room.images?.length || 0} images
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    <button
                      onClick={() => openImageModal(room)}
                      className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300 mr-2"
                      title="Manage Images"
                    >
                      📷
                    </button>
                    <button
                      onClick={() => handleEdit(room)}
                      className="text-green-600 hover:text-green-900 dark:text-green-400 dark:hover:text-green-300 mr-2"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(room.id)}
                      className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {rooms.length === 0 && (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">
            No rooms found. Create your first room to get started.
          </div>
        )}
      </div>

      {/* Room Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                  {editingRoom ? 'Edit Room' : 'Add New Room'}
                </h2>
                <button
                  onClick={() => {
                    setShowModal(false)
                    setEditingRoom(null)
                    resetForm()
                  }}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  ✕
                </button>
              </div>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Room Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-gold-500 focus:border-gold-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    placeholder="Deluxe King Room"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Description *
                  </label>
                  <textarea
                    required
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    rows="3"
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-gold-500 focus:border-gold-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    placeholder="Luxurious room with king bed and city view..."
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Price per Night (IDR) *
                    </label>
                    <input
                      type="number"
                      required
                      min="0"
                      value={formData.price}
                      onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-gold-500 focus:border-gold-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="500000"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Capacity (Guests) *
                    </label>
                    <input
                      type="number"
                      required
                      min="1"
                      max="10"
                      value={formData.capacity}
                      onChange={(e) => setFormData(prev => ({ ...prev, capacity: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-gold-500 focus:border-gold-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="2"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Size (m²) *
                    </label>
                    <input
                      type="number"
                      required
                      min="1"
                      value={formData.size}
                      onChange={(e) => setFormData(prev => ({ ...prev, size: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-gold-500 focus:border-gold-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="45"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Room Type *
                    </label>
                    <select
                      value={formData.type}
                      onChange={(e) => setFormData(prev => ({ ...prev, type: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-gold-500 focus:border-gold-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    >
                      <option value="STANDARD">Standard</option>
                      <option value="DELUXE">Deluxe</option>
                      <option value="SUITE">Suite</option>
                      <option value="EXECUTIVE">Executive</option>
                      <option value="PRESIDENTIAL">Presidential</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Amenities (comma separated)
                  </label>
                  <input
                    type="text"
                    value={formData.amenities}
                    onChange={(e) => setFormData(prev => ({ ...prev, amenities: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-gold-500 focus:border-gold-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    placeholder="WiFi, AC, TV, Mini Bar, Sea View"
                  />
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Separate multiple amenities with commas
                  </p>
                </div>

                <div className="flex justify-end space-x-3 pt-4 border-t dark:border-gray-600">
                  <button
                    type="button"
                    onClick={() => {
                      setShowModal(false)
                      setEditingRoom(null)
                      resetForm()
                    }}
                    className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white border border-gray-300 dark:border-gray-600 rounded-md"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 text-sm font-medium text-white bg-gold-600 hover:bg-gold-700 rounded-md transition-colors"
                  >
                    {editingRoom ? 'Update Room' : 'Create Room'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Image Management Modal */}
      {showImageModal && selectedRoom && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                  Manage Images - {selectedRoom.name}
                </h2>
                <button
                  onClick={() => {
                    setShowImageModal(false)
                    setSelectedRoom(null)
                    setImageForm({ caption: '', image: null })
                  }}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  ✕
                </button>
              </div>

              {/* Upload Form */}
              <div className="mb-6 p-4 border border-gray-200 dark:border-gray-600 rounded-lg">
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-3">
                  Upload New Image
                </h3>
                <form onSubmit={handleImageUpload} className="space-y-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Image Caption
                    </label>
                    <input
                      type="text"
                      value={imageForm.caption}
                      onChange={(e) => setImageForm(prev => ({ ...prev, caption: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-gold-500 focus:border-gold-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      placeholder="Room view from balcony..."
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Select Image
                    </label>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => setImageForm(prev => ({ ...prev, image: e.target.files[0] }))}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-gold-500 focus:border-gold-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={!imageForm.image}
                    className="bg-gold-600 hover:bg-gold-700 text-white px-4 py-2 rounded-md disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Upload Image
                  </button>
                </form>
              </div>

              {/* Existing Images */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-3">
                  Existing Images ({selectedRoom.images?.length || 0})
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {selectedRoom.images?.map((image) => (
                    <div key={image.id} className="border border-gray-200 dark:border-gray-600 rounded-lg overflow-hidden">
                      <img
                        src={image.url}
                        alt={image.caption}
                        className="w-full h-32 object-cover"
                      />
                      <div className="p-3">
                        <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">
                          {image.caption || 'No caption'}
                        </p>
                        <button
                          onClick={() => handleImageDelete(image.id)}
                          className="w-full bg-red-600 hover:bg-red-700 text-white py-1 px-2 rounded text-sm"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
                {(!selectedRoom.images || selectedRoom.images.length === 0) && (
                  <p className="text-gray-500 dark:text-gray-400 text-center py-4">
                    No images uploaded for this room yet.
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default AdminRooms