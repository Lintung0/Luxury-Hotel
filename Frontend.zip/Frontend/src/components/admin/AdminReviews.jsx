// src/components/admin/AdminReviews.jsx
// Component untuk admin review management dengan delete operations
import React, { useState, useEffect } from 'react'
import { deleteAdminReview } from '../../api/adminApi/adminReviewApi'
import AdminTableSkeleton from '../ui/AdminTableSkeleton'
import { formatDate } from '../../utils/formatter'

const AdminReviews = () => {
  const [reviews, setReviews] = useState([])
  const [loading, setLoading] = useState(true)
  const [selectedReview, setSelectedReview] = useState(null)
  const [showDetailModal, setShowDetailModal] = useState(false)

  useEffect(() => {
    loadReviews()
  }, [])

  // Note: Since there's no direct endpoint to get all reviews for admin,
  // we'll need to fetch reviews room by room or implement a workaround
  // For now, this is a placeholder implementation
  const loadReviews = async () => {
    try {
      // This would need to be implemented based on available endpoints
      // For demo purposes, we'll show an empty state
      setReviews([])
    } catch (error) {
      console.error('Failed to load reviews:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleViewDetails = (review) => {
    setSelectedReview(review)
    setShowDetailModal(true)
  }

  const handleDelete = async (reviewId) => {
    if (window.confirm('Are you sure you want to delete this review? This action cannot be undone.')) {
      try {
        await deleteAdminReview(reviewId)
        loadReviews() // Refresh the list
        alert('Review deleted successfully')
      } catch (error) {
        console.error('Failed to delete review:', error)
        alert('Failed to delete review: ' + (error.response?.data?.message || error.message))
      }
    }
  }

  const getRatingColor = (rating) => {
    if (rating >= 4) return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
    if (rating >= 3) return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
    return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
  }

  const renderStars = (rating) => {
    return (
      <div className="flex items-center">
        {[1, 2, 3, 4, 5].map((star) => (
          <span
            key={star}
            className={`text-lg ${
              star <= rating ? 'text-yellow-400' : 'text-gray-300 dark:text-gray-600'
            }`}
          >
            ★
          </span>
        ))}
        <span className="ml-2 text-sm text-gray-500 dark:text-gray-400">
          ({rating.toFixed(1)})
        </span>
      </div>
    )
  }

  // Mock data for demonstration
  const mockReviews = [
    {
      id: 1,
      user: { name: 'John Doe', email: 'john@example.com' },
      room: { name: 'Deluxe King Room', id: 1 },
      rating: 5,
      title: 'Excellent Stay!',
      comment: 'The room was absolutely wonderful. Great view and comfortable bed.',
      created_at: '2024-01-15T10:30:00Z',
      is_verified: true
    },
    {
      id: 2,
      user: { name: 'Jane Smith', email: 'jane@example.com' },
      room: { name: 'Executive Suite', id: 2 },
      rating: 4,
      title: 'Very Good',
      comment: 'Nice room with good amenities. Would stay again.',
      created_at: '2024-01-10T14:20:00Z',
      is_verified: true
    },
    {
      id: 3,
      user: { name: 'Bob Johnson', email: 'bob@example.com' },
      room: { name: 'Standard Room', id: 3 },
      rating: 3,
      title: 'Average Experience',
      comment: 'Room was okay but could use some updates.',
      created_at: '2024-01-05T09:15:00Z',
      is_verified: false
    }
  ]

  if (loading) {
    return <AdminTableSkeleton />
  }

  const displayReviews = reviews.length > 0 ? reviews : mockReviews

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          Review Management
        </h1>
        <div className="text-sm text-gray-500 dark:text-gray-400">
          Total: {displayReviews.length} reviews
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 shadow-lg rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Review
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Room
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Rating
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Date
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {displayReviews.map((review) => (
                <tr key={review.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                  <td className="px-6 py-4">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">
                      {review.title}
                    </div>
                    <div className="text-sm text-gray-500 dark:text-gray-400 truncate max-w-xs">
                      {review.comment}
                    </div>
                    <div className="text-xs text-gray-400 dark:text-gray-500 mt-1">
                      by {review.user?.name}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                    {review.room?.name}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {renderStars(review.rating)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                    {formatDate(review.created_at)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                      review.is_verified 
                        ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' 
                        : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200'
                    }`}>
                      {review.is_verified ? 'Verified' : 'Pending'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    <button
                      onClick={() => handleViewDetails(review)}
                      className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300"
                    >
                      View
                    </button>
                    <button
                      onClick={() => handleDelete(review.id)}
                      className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {displayReviews.length === 0 && (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">
            No reviews found.
          </div>
        )}
      </div>

      {/* Review Detail Modal */}
      {showDetailModal && selectedReview && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                  Review Details
                </h2>
                <button
                  onClick={() => {
                    setShowDetailModal(false)
                    setSelectedReview(null)
                  }}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-6">
                {/* Review Header */}
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                      {selectedReview.title}
                    </h3>
                    <div className="flex items-center space-x-4 mt-1">
                      {renderStars(selectedReview.rating)}
                      <span className="text-sm text-gray-500 dark:text-gray-400">
                        {formatDate(selectedReview.created_at)}
                      </span>
                    </div>
                  </div>
                  <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getRatingColor(selectedReview.rating)}`}>
                    {selectedReview.rating}/5
                  </span>
                </div>

                {/* User Information */}
                <div>
                  <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">
                    Reviewed by
                  </h4>
                  <div className="flex items-center space-x-3">
                    <div className="flex-shrink-0 h-10 w-10 bg-gold-600 rounded-full flex items-center justify-center">
                      <span className="text-white font-medium text-sm">
                        {selectedReview.user?.name?.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900 dark:text-white">
                        {selectedReview.user?.name}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {selectedReview.user?.email}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Room Information */}
                <div>
                  <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">
                    Room Information
                  </h4>
                  <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                      {selectedReview.room?.name}
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Room ID: {selectedReview.room?.id}
                    </p>
                  </div>
                </div>

                {/* Review Content */}
                <div>
                  <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">
                    Review Content
                  </h4>
                  <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                    <p className="text-gray-900 dark:text-white whitespace-pre-wrap">
                      {selectedReview.comment}
                    </p>
                  </div>
                </div>

                {/* Review Metadata */}
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium text-gray-500 dark:text-gray-400">Status:</span>
                    <p>
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        selectedReview.is_verified 
                          ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' 
                          : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200'
                      }`}>
                        {selectedReview.is_verified ? 'Verified Stay' : 'Not Verified'}
                      </span>
                    </p>
                  </div>
                  <div>
                    <span className="font-medium text-gray-500 dark:text-gray-400">Review Date:</span>
                    <p className="text-gray-900 dark:text-white">
                      {formatDate(selectedReview.created_at)}
                    </p>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex justify-end space-x-3 pt-4 border-t dark:border-gray-600">
                  <button
                    onClick={() => {
                      setShowDetailModal(false)
                      setSelectedReview(null)
                    }}
                    className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white border border-gray-300 dark:border-gray-600 rounded-md"
                  >
                    Close
                  </button>
                  <button
                    onClick={() => {
                      handleDelete(selectedReview.id)
                      setShowDetailModal(false)
                    }}
                    className="px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-md"
                  >
                    Delete Review
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default AdminReviews