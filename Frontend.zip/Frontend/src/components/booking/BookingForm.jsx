// src/components/booking/BookingForm.jsx
// Component untuk form booking room
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { createBooking } from '../../api/bookingApi'
import { formatCurrency, formatDateForInput } from '../../utils/formatter'

const BookingForm = ({ room }) => {
  const [formData, setFormData] = useState({
    checkin: '',
    checkout: '',
    guests: room.capacity || 1,
    specialRequests: ''
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const { user } = useAuth()
  const navigate = useNavigate()

  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }))
  }

  const calculateTotal = () => {
    if (!formData.checkin || !formData.checkout) return 0
    
    const checkin = new Date(formData.checkin)
    const checkout = new Date(formData.checkout)
    const nights = Math.ceil((checkout - checkin) / (1000 * 60 * 60 * 24))
    
    return nights > 0 ? nights * room.price : 0
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!user) {
      navigate('/login', { state: { from: `/rooms/${room.id}` } })
      return
    }

    setLoading(true)
    setError('')

    try {
      const bookingData = {
        room_id: room.id,
        checkin: formData.checkin,
        checkout: formData.checkout,
        guests: parseInt(formData.guests),
        special_requests: formData.specialRequests
      }

await createBooking(bookingData)
    navigate('/member/bookings', { 
      state: { message: 'Booking created successfully!' } 
    })
  } catch (err) {
    setError(err.response?.data?.message || 'Booking failed')
  } finally {
    setLoading(false)
  }
}

  const today = formatDateForInput(new Date())
  const minCheckout = formData.checkin ? 
    formatDateForInput(new Date(new Date(formData.checkin).getTime() + 86400000)) : 
    today

  const total = calculateTotal()
  const nights = total / room.price

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 sticky top-4">
      <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
        Book This Room
      </h3>

      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="bg-red-100 dark:bg-red-900 border border-red-400 dark:border-red-700 text-red-700 dark:text-red-300 px-4 py-3 rounded text-sm">
            {error}
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Check-in Date
          </label>
          <input
            type="date"
            name="checkin"
            min={today}
            required
            value={formData.checkin}
            onChange={handleChange}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-gold-500 focus:border-gold-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Check-out Date
          </label>
          <input
            type="date"
            name="checkout"
            min={minCheckout}
            required
            value={formData.checkout}
            onChange={handleChange}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-gold-500 focus:border-gold-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Guests
          </label>
          <select
            name="guests"
            value={formData.guests}
            onChange={handleChange}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-gold-500 focus:border-gold-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          >
            {[...Array(room.capacity)].map((_, i) => (
              <option key={i + 1} value={i + 1}>
                {i + 1} {i + 1 === 1 ? 'Guest' : 'Guests'}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Special Requests
          </label>
          <textarea
            name="specialRequests"
            rows="3"
            value={formData.specialRequests}
            onChange={handleChange}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-gold-500 focus:border-gold-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            placeholder="Any special requests..."
          />
        </div>

        {total > 0 && (
          <div className="border-t dark:border-gray-600 pt-4">
            <div className="flex justify-between text-sm text-gray-600 dark:text-gray-300 mb-2">
              <span>{room.price} x {nights} nights</span>
              <span>{formatCurrency(total)}</span>
            </div>
            <div className="flex justify-between text-lg font-semibold text-gray-900 dark:text-white">
              <span>Total</span>
              <span className="text-gold-600">{formatCurrency(total)}</span>
            </div>
          </div>
        )}

        <button
          type="submit"
          disabled={loading || !formData.checkin || !formData.checkout}
          className="w-full bg-gold-600 hover:bg-gold-700 text-white py-3 px-4 rounded-md font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? 'Booking...' : user ? 'Book Now' : 'Login to Book'}
        </button>
      </form>
    </div>
  )
}

export default BookingForm