// src/components/booking/BookingCard.jsx
// Component untuk menampilkan card booking individual
import React from 'react'
import { formatCurrency, formatDate } from '../../utils/formatter'

const BookingCard = ({ booking, onCancel }) => {
  const getStatusColor = (status) => {
    switch (status?.toLowerCase()) {
      case 'confirmed':
        return 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200'
      case 'pending':
        return 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200'
      case 'cancelled':
        return 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
      default:
        return 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200'
    }
  }

  const canCancel = booking.status?.toLowerCase() === 'confirmed' || 
                   booking.status?.toLowerCase() === 'pending'

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 gold-glow">
      <div className="flex justify-between items-start mb-4">
        <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
          {booking.room?.name || 'Room'}
        </h3>
        <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(booking.status)}`}>
          {booking.status}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
        <div>
          <div className="text-sm text-gray-500 dark:text-gray-400">Check-in</div>
          <div className="font-medium text-gray-900 dark:text-white">
            {formatDate(booking.checkin)}
          </div>
        </div>
        <div>
          <div className="text-sm text-gray-500 dark:text-gray-400">Check-out</div>
          <div className="font-medium text-gray-900 dark:text-white">
            {formatDate(booking.checkout)}
          </div>
        </div>
        <div>
          <div className="text-sm text-gray-500 dark:text-gray-400">Guests</div>
          <div className="font-medium text-gray-900 dark:text-white">
            {booking.guests}
          </div>
        </div>
      </div>

      {booking.special_requests && (
        <div className="mb-4">
          <div className="text-sm text-gray-500 dark:text-gray-400">Special Requests</div>
          <div className="text-gray-900 dark:text-white text-sm">
            {booking.special_requests}
          </div>
        </div>
      )}

      <div className="flex justify-between items-center">
        <div className="text-lg font-semibold text-gold-600">
          {formatCurrency(booking.total_price)}
        </div>
        
        {canCancel && onCancel && (
          <button
            onClick={() => onCancel(booking.id)}
            className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"
          >
            Cancel Booking
          </button>
        )}
      </div>
    </div>
  )
}

export default BookingCard