// src/components/rooms/RoomDetail.jsx
// Component untuk menampilkan detail room lengkap
import React, { useState } from 'react'
import { formatCurrency } from '../../utils/formatter'
import BookingForm from '../booking/BookingForm'

const RoomDetail = ({ room, loading }) => {
  const [selectedImage, setSelectedImage] = useState(0)

  if (loading || !room) {
    return null // Skeleton akan dihandle di page
  }

  const images = room.images || [
    { url: 'https://via.placeholder.com/800x600?text=Room+Image', caption: 'Room View' }
  ]

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Image Gallery */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-8">
        <div className="lg:col-span-2">
          <img
            src={images[selectedImage]?.url}
            alt={images[selectedImage]?.caption || room.name}
            className="w-full h-96 lg:h-[400px] object-cover rounded-lg shadow-lg"
          />
        </div>
        <div className="grid grid-cols-2 gap-4">
          {images.slice(0, 4).map((image, index) => (
            <button
              key={index}
              onClick={() => setSelectedImage(index)}
              className={`relative h-44 rounded-lg overflow-hidden ${
                selectedImage === index ? 'ring-2 ring-gold-600' : ''
              }`}
            >
              <img
                src={image.url}
                alt={image.caption}
                className="w-full h-full object-cover"
              />
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Room Details */}
        <div className="lg:col-span-2">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            {room.name}
          </h1>
          
          <p className="text-gray-600 dark:text-gray-300 text-lg mb-6">
            {room.description}
          </p>

          <div className="grid grid-cols-2 gap-6 mb-8">
            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
              <div className="text-sm text-gray-500 dark:text-gray-400">Price</div>
              <div className="text-2xl font-bold text-gold-600">
                {formatCurrency(room.price)}
                <span className="text-sm font-normal text-gray-500 dark:text-gray-400"> / night</span>
              </div>
            </div>
            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
              <div className="text-sm text-gray-500 dark:text-gray-400">Size</div>
              <div className="text-2xl font-bold text-gray-900 dark:text-white">
                {room.size}m²
              </div>
            </div>
            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
              <div className="text-sm text-gray-500 dark:text-gray-400">Capacity</div>
              <div className="text-2xl font-bold text-gray-900 dark:text-white">
                {room.capacity} Guests
              </div>
            </div>
            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
              <div className="text-sm text-gray-500 dark:text-gray-400">Type</div>
              <div className="text-xl font-semibold text-gray-900 dark:text-white">
                {room.type || 'Standard'}
              </div>
            </div>
          </div>

          {/* Amenities */}
          <div>
            <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
              Amenities
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {room.amenities?.map((amenity, index) => (
                <div
                  key={index}
                  className="flex items-center space-x-2 text-gray-600 dark:text-gray-300"
                >
                  <div className="w-2 h-2 bg-gold-600 rounded-full"></div>
                  <span>{amenity}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Booking Form */}
        <div className="lg:col-span-1">
          <BookingForm room={room} />
        </div>
      </div>
    </div>
  )
}

export default RoomDetail