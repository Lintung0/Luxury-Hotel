// src/components/rooms/RoomCard.jsx
// Component untuk menampilkan card room individual
import React from 'react'
import { Link } from 'react-router-dom'
import { formatCurrency } from '../../utils/formatter'

const RoomCard = ({ room }) => {
  const mainImage = room.images?.[0]?.url || 'https://via.placeholder.com/400x300?text=Room+Image'

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden gold-glow hover:shadow-xl transition-all duration-300">
      <div className="relative overflow-hidden">
        <img
          src={mainImage}
          alt={room.name}
          className="w-full h-48 object-cover transition-transform duration-300 hover:scale-105"
        />
        <div className="absolute top-4 right-4">
          <span className="bg-gold-600 text-white px-2 py-1 rounded-full text-xs font-semibold">
            {room.capacity} Guests
          </span>
        </div>
      </div>

      <div className="p-4">
        <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
          {room.name}
        </h3>
        
        <p className="text-gray-600 dark:text-gray-300 text-sm mb-3 line-clamp-2">
          {room.description}
        </p>

        <div className="flex items-center justify-between mb-4">
          <div className="text-sm text-gray-500 dark:text-gray-400">
            <span className="text-gold-600 font-semibold">
              {formatCurrency(room.price)}
            </span>
            <span className="text-gray-400 dark:text-gray-500"> / night</span>
          </div>
          <div className="text-sm text-gray-500 dark:text-gray-400">
            {room.size} m²
          </div>
        </div>

        <div className="flex flex-wrap gap-1 mb-4">
          {room.amenities?.slice(0, 3).map((amenity, index) => (
            <span
              key={index}
              className="bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-xs px-2 py-1 rounded"
            >
              {amenity}
            </span>
          ))}
          {room.amenities?.length > 3 && (
            <span className="text-gray-500 dark:text-gray-400 text-xs">
              +{room.amenities.length - 3} more
            </span>
          )}
        </div>

        <Link
          to={`/rooms/${room.id}`}
          className="block w-full bg-gold-600 hover:bg-gold-700 text-white text-center py-2 px-4 rounded-lg font-medium transition-colors duration-200"
        >
          View Details
        </Link>
      </div>
    </div>
  )
}

export default RoomCard