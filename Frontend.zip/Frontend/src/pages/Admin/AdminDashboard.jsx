// src/pages/Admin/AdminDashboard.jsx
// Admin dashboard dengan overview statistics
import React from 'react'

const AdminDashboard = () => {
  const stats = [
    { label: 'Total Rooms', value: '24', change: '+2' },
    { label: 'Active Bookings', value: '156', change: '+12' },
    { label: 'Today Check-ins', value: '8', change: '+3' },
    { label: 'Revenue', value: '₿24.8M', change: '+18%' },
  ]

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
        Dashboard Overview
      </h1>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <div
            key={index}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                  {stat.label}
                </p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                  {stat.value}
                </p>
              </div>
              <div className="text-right">
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                  {stat.change}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
          Quick Actions
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: 'Add New Room', href: '/admin/rooms', icon: '➕' },
            { label: 'View Bookings', href: '/admin/bookings', icon: '📅' },
            { label: 'Manage Users', href: '/admin/users', icon: '👥' },
            { label: 'Room Reviews', href: '/admin/reviews', icon: '⭐' },
          ].map((action, index) => (
            <a
              key={index}
              href={action.href}
              className="flex items-center p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:border-gold-500 dark:hover:border-gold-500 transition-colors"
            >
              <span className="text-2xl mr-3">{action.icon}</span>
              <span className="font-medium text-gray-900 dark:text-white">
                {action.label}
              </span>
            </a>
          ))}
        </div>
      </div>
    </div>
  )
}

export default AdminDashboard