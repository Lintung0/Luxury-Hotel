// src/pages/Member/MemberBookings.jsx
// Page untuk member melihat dan mengelola bookings mereka
import React, { useState, useEffect } from 'react'
import { getMemberBookings, cancelBooking } from '../../api/bookingApi'
import BookingCard from '../../components/booking/BookingCard'
import BookingListSkeleton from '../../components/ui/BookingListSkeleton'

const MemberBookings = () => {
  const [bookings, setBookings] = useState([])
  const [loading, setLoading] = useState(true)
  const [message, setMessage] = useState('')

  useEffect(() => {
    loadBookings()
  }, [])

  const loadBookings = async () => {
    try {
      const data = await getMemberBookings()
      setBookings(data.bookings || data)
    } catch (error) {
      console.error('Failed to load bookings:', error)
      setBookings([])
    } finally {
      setLoading(false)
    }
  }

  const handleCancelBooking = async (bookingId) => {
    if (!window.confirm('Are you sure you want to cancel this booking?')) {
      return
    }

    try {
      await cancelBooking(bookingId)
      setMessage('Booking cancelled successfully')
      loadBookings() // Refresh the list
    } catch (error) {
      setMessage('Failed to cancel booking')
      console.error('Error cancelling booking:', error)
    }
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
          My Bookings
        </h1>
        <p className="text-lg text-gray-600 dark:text-gray-300">
          Manage your upcoming and past bookings
        </p>
      </div>

      {message && (
        <div className={`mb-6 p-4 rounded-md ${
          message.includes('success') 
            ? 'bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300' 
            : 'bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300'
        }`}>
          {message}
        </div>
      )}

      {loading ? (
        <BookingListSkeleton />
      ) : bookings.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-gray-500 dark:text-gray-400 text-lg mb-4">
            You don't have any bookings yet
          </div>
          <a
            href="/rooms"
            className="text-gold-600 hover:text-gold-700 font-medium"
          >
            Browse Rooms
          </a>
        </div>
      ) : (
        <div className="space-y-6">
          {bookings.map((booking) => (
            <BookingCard
              key={booking.id}
              booking={booking}
              onCancel={handleCancelBooking}
            />
          ))}
        </div>
      )}
    </div>
  )
}

export default MemberBookings