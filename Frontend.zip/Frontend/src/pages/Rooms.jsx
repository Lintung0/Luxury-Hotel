// src/pages/Rooms.jsx
// Rooms page untuk menampilkan semua available rooms
import React, { useState, useEffect } from 'react'
import { getAvailableRooms } from '../api/roomApi'
import RoomList from '../components/rooms/RoomList'
import PageSkeleton from '../components/ui/PageSkeleton'

const Rooms = () => {
  const [rooms, setRooms] = useState([])
  const [loading, setLoading] = useState(true)
  const [filters, setFilters] = useState({
    checkin: '',
    checkout: '',
    guests: 1
  })

  useEffect(() => {
    loadRooms()
  }, [])

  const loadRooms = async (searchFilters = null) => {
    try {
      setLoading(true)
      const data = await getAvailableRooms(searchFilters || {})
      setRooms(data.rooms || data)
    } catch (error) {
      console.error('Failed to load rooms:', error)
      setRooms([])
    } finally {
      setLoading(false)
    }
  }

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }))
  }

  const handleSearch = (e) => {
    e.preventDefault()
    loadRooms(filters)
  }

  if (loading && rooms.length === 0) {
    return <PageSkeleton />
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
          Our Luxury Rooms
        </h1>
        <p className="text-lg text-gray-600 dark:text-gray-300">
          Discover our exquisite collection of rooms and suites
        </p>
      </div>

      {/* Search Filters */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 mb-8">
        <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Check-in Date
            </label>
            <input
              type="date"
              value={filters.checkin}
              onChange={(e) => handleFilterChange('checkin', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-gold-500 focus:border-gold-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Check-out Date
            </label>
            <input
              type="date"
              value={filters.checkout}
              onChange={(e) => handleFilterChange('checkout', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-gold-500 focus:border-gold-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Guests
            </label>
            <select
              value={filters.guests}
              onChange={(e) => handleFilterChange('guests', parseInt(e.target.value))}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-gold-500 focus:border-gold-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              {[1, 2, 3, 4, 5, 6].map(num => (
                <option key={num} value={num}>
                  {num} {num === 1 ? 'Guest' : 'Guests'}
                </option>
              ))}
            </select>
          </div>
          
          <div className="flex items-end">
            <button
              type="submit"
              className="w-full bg-gold-600 hover:bg-gold-700 text-white py-2 px-4 rounded-md font-medium transition-colors"
            >
              Search Rooms
            </button>
          </div>
        </form>
      </div>

      {/* Rooms List */}
      <RoomList rooms={rooms} loading={loading} />
    </div>
  )
}

export default Rooms